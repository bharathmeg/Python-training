a=int(input("enter yout number:"))
b=int(input("enter yout number:"))
c=a^b
d=a^b
c=a^b
print(c)
print(d)

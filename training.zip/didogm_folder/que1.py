a,b,c = map(int,input("enter your number:").split())
print(a,b,c)
w=int(input("enter your weight:"))

if w>2 and w%2==0:
    print("YES")
else:
    print("NO")


